// lexer.js - from attached documents
