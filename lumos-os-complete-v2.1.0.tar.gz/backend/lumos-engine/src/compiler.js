// compiler.js - from attached documents
