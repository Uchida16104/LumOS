// parser.js - from attached documents
