// evaluator.js - from attached documents
